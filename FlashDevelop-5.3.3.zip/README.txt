Before you customize any files here, be sure you have read the customization notes from the wiki:
http://www.flashdevelop.org/wikidocs/index.php?title=Configuration

You can run our maintenance tool (FDMT.cmd) from FD dir to for example toggle between different run modes.
